import express from 'express';
import bookRoutes from '../routes/books';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Express API routes
app.use('/api', bookRoutes);

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'Simple Book Shop (Vercel API)', timestamp: new Date().toISOString() });
});

export default app;
