import { Router, Request, Response } from 'express';
import fs from 'fs';
import path from 'path';

const router = Router();

// Helper paths to data files
const booksFilePath = path.join(process.cwd(), 'data', 'books.json');
const ordersFilePath = path.join(process.cwd(), 'data', 'orders.json');

// Helper function to safely read JSON file
function readJsonFile(filePath: string) {
  try {
    if (!fs.existsSync(filePath)) {
      return [];
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
    return [];
  }
}

// Helper function to safely write JSON file
function writeJsonFile(filePath: string, data: any) {
  try {
    const dirPath = path.dirname(filePath);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
    return false;
  }
}

/**
 * @route   GET /api/books
 * @desc    Fetch all books with search, category filtering, and sorting
 */
router.get('/books', (req: Request, res: Response) => {
  let books = readJsonFile(booksFilePath);

  const search = typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
  const category = typeof req.query.category === 'string' ? req.query.category.trim() : 'All';
  const sort = typeof req.query.sort === 'string' ? req.query.sort : 'popular';
  const featuredOnly = req.query.featured === 'true';

  // Filter by search keyword (title or author)
  if (search) {
    books = books.filter((book: any) =>
      book.title.toLowerCase().includes(search) ||
      book.author.toLowerCase().includes(search) ||
      book.category.toLowerCase().includes(search)
    );
  }

  // Filter by category
  if (category && category !== 'All') {
    books = books.filter((book: any) =>
      book.category.toLowerCase() === category.toLowerCase()
    );
  }

  // Filter featured
  if (featuredOnly) {
    books = books.filter((book: any) => book.featured === true);
  }

  // Sorting logic
  if (sort === 'price-low') {
    books.sort((a: any, b: any) => a.price - b.price);
  } else if (sort === 'price-high') {
    books.sort((a: any, b: any) => b.price - a.price);
  } else if (sort === 'rating') {
    books.sort((a: any, b: any) => b.rating - a.rating);
  } else if (sort === 'title') {
    books.sort((a: any, b: any) => a.title.localeCompare(b.title));
  } else {
    // Default: Popularity / Rating
    books.sort((a: any, b: any) => (b.badge ? 1 : 0) - (a.badge ? 1 : 0));
  }

  res.json({
    success: true,
    count: books.length,
    data: books
  });
});

/**
 * @route   GET /api/books/:id
 * @desc    Fetch single book by ID
 */
router.get('/books/:id', (req: Request, res: Response) => {
  const books = readJsonFile(booksFilePath);
  const book = books.find((b: any) => b.id === req.params.id);

  if (!book) {
    return res.status(404).json({
      success: false,
      message: `Book with ID ${req.params.id} not found.`
    });
  }

  res.json({
    success: true,
    data: book
  });
});

/**
 * @route   GET /api/categories
 * @desc    Fetch all unique book categories
 */
router.get('/categories', (req: Request, res: Response) => {
  const books = readJsonFile(booksFilePath);
  const categoriesSet = new Set<string>();

  books.forEach((book: any) => {
    if (book.category) {
      categoriesSet.add(book.category);
    }
  });

  const categories = ['All', ...Array.from(categoriesSet)];

  res.json({
    success: true,
    data: categories
  });
});

/**
 * @route   POST /api/checkout
 * @desc    Submit checkout order, calculate totals, and save order
 */
router.post('/checkout', (req: Request, res: Response) => {
  const { customer, items, promoCode } = req.body;

  if (!customer || !customer.name || !customer.email || !customer.address) {
    return res.status(400).json({
      success: false,
      message: 'Please provide valid customer details (Name, Email, and Address).'
    });
  }

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      success: false,
      message: 'Your shopping cart is empty.'
    });
  }

  // Calculate Subtotal
  let subtotal = 0;
  const processedItems = items.map((item: any) => {
    const qty = Math.max(1, parseInt(item.quantity) || 1);
    const itemTotal = Number(item.price) * qty;
    subtotal += itemTotal;
    return {
      id: item.id,
      title: item.title,
      author: item.author,
      price: Number(item.price),
      quantity: qty,
      itemTotal
    };
  });

  // Apply Promo discount if applicable (e.g. BOOK10 for 10% off)
  let discount = 0;
  if (promoCode && promoCode.trim().toUpperCase() === 'BOOKSHOP10') {
    discount = Number((subtotal * 0.10).toFixed(2));
  }

  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = Number((taxableAmount * 0.08).toFixed(2)); // 8% tax rate
  const shipping = taxableAmount > 35 ? 0 : 4.99; // Free shipping over $35
  const total = Number((taxableAmount + tax + shipping).toFixed(2));

  // Generate unique order ID
  const orderId = `ORD-${Date.now().toString().slice(-6)}`;

  const orderData = {
    orderId,
    customer: {
      name: customer.name.trim(),
      email: customer.email.trim(),
      address: customer.address.trim(),
      city: customer.city ? customer.city.trim() : 'Booktown',
      zip: customer.zip ? customer.zip.trim() : '00000',
      paymentMethod: customer.paymentMethod || 'Credit Card'
    },
    items: processedItems,
    subtotal: Number(subtotal.toFixed(2)),
    discount,
    tax,
    shipping,
    total,
    createdAt: new Date().toISOString(),
    status: 'Confirmed'
  };

  // Save order to orders.json
  const existingOrders = readJsonFile(ordersFilePath);
  existingOrders.unshift(orderData);
  writeJsonFile(ordersFilePath, existingOrders);

  res.status(201).json({
    success: true,
    message: 'Order placed successfully!',
    order: orderData
  });
});

/**
 * @route   GET /api/orders/:id
 * @desc    Fetch single order receipt
 */
router.get('/orders/:id', (req: Request, res: Response) => {
  const orders = readJsonFile(ordersFilePath);
  const order = orders.find((o: any) => o.orderId === req.params.id);

  if (!order) {
    return res.status(404).json({
      success: false,
      message: `Order ${req.params.id} not found.`
    });
  }

  res.json({
    success: true,
    data: order
  });
});

export default router;
