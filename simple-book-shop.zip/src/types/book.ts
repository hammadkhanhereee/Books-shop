export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  originalPrice?: number;
  category: string;
  rating: number;
  reviewsCount: number;
  coverImage: string;
  description: string;
  publisher: string;
  publishedYear: number;
  pages: number;
  isbn: string;
  inStock: boolean;
  stockCount: number;
  featured?: boolean;
  badge?: string;
}

export interface CartItem extends Book {
  quantity: number;
}

export interface CustomerInfo {
  name: string;
  email: string;
  address: string;
  city: string;
  zip: string;
  paymentMethod: string;
}

export interface OrderReceipt {
  orderId: string;
  customer: CustomerInfo;
  items: {
    id: string;
    title: string;
    author: string;
    price: number;
    quantity: number;
    itemTotal: number;
  }[];
  subtotal: number;
  discount: number;
  tax: number;
  shipping: number;
  total: number;
  createdAt: string;
  status: string;
}
