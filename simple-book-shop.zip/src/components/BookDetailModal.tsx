import React, { useState } from 'react';
import { X, Star, ShoppingBag, Truck, ShieldCheck, Check, BookOpen } from 'lucide-react';
import { Book } from '../types/book';

interface BookDetailModalProps {
  book: Book | null;
  onClose: () => void;
  onAddToCart: (book: Book, quantity: number) => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({
  book,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [added, setAdded] = useState<boolean>(false);

  if (!book) return null;

  const handleAdd = () => {
    onAddToCart(book, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 relative max-h-[90vh] flex flex-col sm:flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-slate-100 hover:bg-slate-200 text-slate-600 p-2 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Cover Image */}
        <div className="sm:w-1/2 bg-slate-100 p-6 flex items-center justify-center relative">
          <img
            src={book.coverImage}
            alt={book.title}
            className="max-h-80 w-auto object-contain rounded-xl shadow-lg"
            referrerPolicy="no-referrer"
          />
          {book.badge && (
            <span className="absolute top-4 left-4 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-md shadow">
              {book.badge}
            </span>
          )}
        </div>

        {/* Right Details */}
        <div className="sm:w-1/2 p-6 overflow-y-auto flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                {book.category}
              </span>
              <span className="text-slate-300">•</span>
              <div className="flex items-center text-amber-500 text-xs font-bold gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                <span>{book.rating.toFixed(1)}</span>
                <span className="text-slate-400">({book.reviewsCount} reviews)</span>
              </div>
            </div>

            <h2 className="text-2xl font-black text-slate-900 leading-tight mb-1">
              {book.title}
            </h2>
            <p className="text-xs text-slate-500 mb-4 font-medium">Author: {book.author}</p>

            <p className="text-xs text-slate-600 leading-relaxed mb-4">
              {book.description}
            </p>

            {/* Book Metadata Grid */}
            <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 p-3 rounded-xl border border-slate-200/80 mb-4 text-slate-600">
              <div><span className="font-semibold text-slate-800">Publisher:</span> {book.publisher}</div>
              <div><span className="font-semibold text-slate-800">Published:</span> {book.publishedYear}</div>
              <div><span className="font-semibold text-slate-800">Pages:</span> {book.pages} pages</div>
              <div><span className="font-semibold text-slate-800">ISBN:</span> {book.isbn}</div>
            </div>

            <div className="flex items-center gap-2 text-xs text-emerald-600 font-semibold mb-4">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>In Stock ({book.stockCount} copies available)</span>
            </div>
          </div>

          {/* Pricing & Add Action */}
          <div className="border-t pt-4 mt-2">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-2xl font-black text-slate-900">
                  ${book.price.toFixed(2)}
                </span>
                {book.originalPrice && (
                  <span className="text-xs text-slate-400 line-through ml-2">
                    ${book.originalPrice.toFixed(2)}
                  </span>
                )}
              </div>

              {/* Quantity Selector */}
              <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-slate-50 text-xs font-bold">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1.5 hover:bg-slate-200 text-slate-700 transition"
                >
                  -
                </button>
                <span className="px-3 py-1.5 text-slate-900">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1.5 hover:bg-slate-200 text-slate-700 transition"
                >
                  +
                </button>
              </div>
            </div>

            <button
              onClick={handleAdd}
              className={`w-full py-3 rounded-xl font-bold text-sm shadow-md transition-all duration-200 flex items-center justify-center gap-2 ${
                added
                  ? 'bg-emerald-600 text-white'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Added {quantity} Copy to Cart!</span>
                </>
              ) : (
                <>
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add {quantity} to Cart - ${(book.price * quantity).toFixed(2)}</span>
                </>
              )}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
