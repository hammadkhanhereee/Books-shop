import React, { useState } from 'react';
import { X, CheckCircle2, CreditCard, Truck, Printer, ArrowLeft, ShieldCheck, ShoppingBag } from 'lucide-react';
import { CartItem, OrderReceipt } from '../types/book';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  promoCode: string;
  onClearCart: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  promoCode,
  onClearCart,
}) => {
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [orderReceipt, setOrderReceipt] = useState<OrderReceipt | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: 'Booktown',
    zip: '90210',
    paymentMethod: 'Credit Card',
  });

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = promoCode === 'BOOKSHOP10' ? Number((subtotal * 0.10).toFixed(2)) : 0;
  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = Number((taxableAmount * 0.08).toFixed(2));
  const shipping = taxableAmount > 35 || items.length === 0 ? 0 : 4.99;
  const total = Number((taxableAmount + tax + shipping).toFixed(2));

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.address) {
      setErrorMsg('Please fill in all required customer details.');
      return;
    }

    setLoading(true);
    setErrorMsg('');

    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: formData,
          items,
          promoCode,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setOrderReceipt(data.order);
        setStep('success');
        onClearCart();
      } else {
        setErrorMsg(data.message || 'Failed to place order. Please try again.');
      }
    } catch (err) {
      console.error('Checkout submit error:', err);
      setErrorMsg('Network error while placing order. Please check server.');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden border border-slate-200 relative max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-400" />
            <h3 className="font-extrabold text-lg">
              {step === 'form' ? 'Checkout & Shipping' : 'Order Receipt'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {step === 'form' ? (
            <form onSubmit={handleSubmitOrder} className="space-y-4">
              
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium">
                  {errorMsg}
                </div>
              )}

              {/* Contact Information */}
              <div>
                <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2">
                  1. Contact & Shipping Information
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Jane Austen"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="jane@example.com"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Street Address *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="123 Library Lane, Apt 4B"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        City
                      </label>
                      <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Postal Zip Code
                      </label>
                      <input
                        type="text"
                        value={formData.zip}
                        onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                        className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="pt-2 border-t">
                <h4 className="text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2">
                  2. Payment Method
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {['Credit Card', 'PayPal', 'Cash on Delivery'].map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setFormData({ ...formData, paymentMethod: method })}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition text-center ${
                        formData.paymentMethod === method
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                          : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              {/* Order Summary Box */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-slate-800 mb-2">Order Items ({items.length})</div>
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-slate-600">
                    <span className="line-clamp-1">{item.title} (x{item.quantity})</span>
                    <span className="font-semibold text-slate-800">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="border-t border-slate-200 pt-2 mt-2 flex justify-between font-extrabold text-sm text-slate-900">
                  <span>Total Amount Due:</span>
                  <span className="text-indigo-600">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-sm rounded-xl shadow-lg transition flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span>Processing Order...</span>
                ) : (
                  <>
                    <span>Confirm & Pay ${total.toFixed(2)}</span>
                  </>
                )}
              </button>

            </form>
          ) : (
            /* Order Success Receipt Step */
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs font-extrabold uppercase text-emerald-600 tracking-wider">
                  Order Successfully Placed!
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-1">
                  Thank You for Your Order!
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  A confirmation email has been sent to <strong>{orderReceipt?.customer.email}</strong>.
                </p>
              </div>

              {/* Printable Receipt Card */}
              {orderReceipt && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left text-xs space-y-3 shadow-inner">
                  <div className="flex justify-between items-center border-b pb-2">
                    <div>
                      <span className="text-slate-400 block text-[10px]">Receipt ID</span>
                      <span className="font-mono font-bold text-indigo-600 text-sm">
                        #{orderReceipt.orderId}
                      </span>
                    </div>
                    <span className="bg-emerald-100 text-emerald-800 font-bold px-2.5 py-1 rounded-md text-[10px]">
                      {orderReceipt.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-600">
                    <div>
                      <span className="font-semibold text-slate-800">Customer:</span> {orderReceipt.customer.name}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800">Payment:</span> {orderReceipt.customer.paymentMethod}
                    </div>
                    <div className="col-span-2">
                      <span className="font-semibold text-slate-800">Shipping Address:</span> {orderReceipt.customer.address}, {orderReceipt.customer.city}
                    </div>
                  </div>

                  <div className="border-t pt-2 space-y-1">
                    <span className="font-bold text-slate-800 block mb-1">Items Purchased:</span>
                    {orderReceipt.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-slate-600">
                        <span>{item.title} (x{item.quantity})</span>
                        <span className="font-medium">${item.itemTotal.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-2 space-y-1 text-slate-600">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>${orderReceipt.subtotal.toFixed(2)}</span>
                    </div>
                    {orderReceipt.discount > 0 && (
                      <div className="flex justify-between text-emerald-600">
                        <span>Discount</span>
                        <span>-${orderReceipt.discount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Tax</span>
                      <span>${orderReceipt.tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Shipping</span>
                      <span>${orderReceipt.shipping.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-extrabold text-sm text-slate-900 border-t pt-2">
                      <span>Total Paid</span>
                      <span className="text-indigo-600">${orderReceipt.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handlePrint}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 border"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Receipt</span>
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow transition"
                >
                  Continue Shopping
                </button>
              </div>

            </div>
          )}
        </div>

      </div>
    </div>
  );
};
