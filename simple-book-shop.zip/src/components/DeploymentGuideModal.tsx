import React, { useState } from 'react';
import { X, Github, Rocket, Check, Copy, ExternalLink, Terminal, Layers, RefreshCw } from 'lucide-react';

interface DeploymentGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeploymentGuideModal: React.FC<DeploymentGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const gitCommands = [
    `git init`,
    `git add .`,
    `git commit -m "Initial commit of Simple Book Shop"`,
    `git branch -M main`,
    `git remote add origin https://github.com/YOUR_USERNAME/simple-book-shop.git`,
    `git push -u origin main`
  ].join('\n');

  return (
    <div className="fixed inset-0 bg-slate-900/75 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div 
        className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden border border-slate-200 relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600/30 rounded-xl border border-indigo-500/30">
              <Rocket className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-xl font-black">GitHub & Vercel Deployment Guide</h2>
              <p className="text-xs text-indigo-300 font-medium">
                Step-by-step instructions to publish your Simple Book Shop to the web
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Scroll */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-slate-700 text-sm">
          
          {/* Step 1: GitHub Instructions */}
          <section className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2 mb-3">
              <Github className="w-5 h-5 text-slate-900" />
              <h3 className="font-extrabold text-base text-slate-900">
                Step 1: Upload Project to GitHub
              </h3>
            </div>
            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-600 leading-relaxed mb-4">
              <li>Log in to your <a href="https://github.com" target="_blank" rel="noreferrer" className="text-indigo-600 underline font-semibold">GitHub account</a> and click <strong>"New Repository"</strong>.</li>
              <li>Name your repository <strong>simple-book-shop</strong>, keep it Public or Private, and leave initialization options unchecked.</li>
              <li>Open your project terminal and run the following commands:</li>
            </ol>

            {/* Code snippet block */}
            <div className="relative bg-slate-900 text-amber-300 p-4 rounded-xl font-mono text-xs overflow-x-auto shadow-inner">
              <button
                onClick={() => copyToClipboard(gitCommands, 1)}
                className="absolute top-3 right-3 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-md text-[11px] flex items-center gap-1 border border-slate-700"
              >
                {copiedIndex === 1 ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedIndex === 1 ? 'Copied!' : 'Copy'}</span>
              </button>
              <pre>{gitCommands}</pre>
            </div>
          </section>

          {/* Step 2: Vercel Deployment Instructions */}
          <section className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2 mb-3">
              <Rocket className="w-5 h-5 text-indigo-600" />
              <h3 className="font-extrabold text-base text-slate-900">
                Step 2: Deploy on Vercel
              </h3>
            </div>
            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-600 leading-relaxed mb-4">
              <li>Visit <a href="https://vercel.com" target="_blank" rel="noreferrer" className="text-indigo-600 underline font-semibold">Vercel.com</a> and sign in with your GitHub account.</li>
              <li>Click <strong>"Add New..." → "Project"</strong> from the dashboard.</li>
              <li>Select your newly pushed <strong>simple-book-shop</strong> repository from the list.</li>
              <li>Vercel automatically detects Vite and Node.js. Confirm the settings:</li>
            </ol>

            <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 text-xs space-y-1.5 mb-3">
              <div className="flex justify-between font-mono">
                <span className="text-slate-500">Framework Preset:</span>
                <span className="font-bold text-slate-900">Vite / Other</span>
              </div>
              <div className="flex justify-between font-mono">
                <span className="text-slate-500">Build Command:</span>
                <span className="font-bold text-slate-900">npm run build</span>
              </div>
              <div className="flex justify-between font-mono">
                <span className="text-slate-500">Output Directory:</span>
                <span className="font-bold text-slate-900">dist</span>
              </div>
            </div>

            <p className="text-xs text-slate-600">
              Click <strong>"Deploy"</strong>. In less than 1 minute, Vercel will build your site and generate a live URL!
            </p>
          </section>

          {/* Step 3: Automatic Continuous Deployment */}
          <section className="bg-indigo-50/70 p-5 rounded-2xl border border-indigo-200">
            <div className="flex items-center gap-2 mb-2">
              <RefreshCw className="w-5 h-5 text-indigo-600 animate-spin-slow" />
              <h3 className="font-extrabold text-base text-indigo-950">
                Step 3: Automatic Deployment on Every Git Push
              </h3>
            </div>
            <p className="text-xs text-indigo-900 leading-relaxed">
              Whenever you make changes to your codebase (e.g., adding new books to <code>data/books.json</code>), simply commit and push your code:
            </p>
            <div className="bg-slate-900 text-indigo-200 p-3 rounded-xl font-mono text-xs my-2">
              git add . && git commit -m "Updated book catalog" && git push
            </div>
            <p className="text-xs text-indigo-900">
              Vercel will automatically trigger a new deployment and update your live website instantly without manual action!
            </p>
          </section>

          {/* Step 4: vercel.json File Explained */}
          <section className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <Layers className="w-5 h-5 text-slate-800" />
              <h3 className="font-extrabold text-base text-slate-900">
                Project Configuration (vercel.json)
              </h3>
            </div>
            <p className="text-xs text-slate-600 mb-3">
              This repository includes a preconfigured <code>vercel.json</code> file to route Express REST API requests to <code>/api</code> and serve static single-page application assets cleanly:
            </p>
            <div className="bg-slate-900 text-amber-300 p-3 rounded-xl font-mono text-[11px] overflow-x-auto">
              <pre>{`{
  "version": 2,
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "rewrites": [
    { "source": "/api/(.*)", "destination": "/api/index.ts" },
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}`}</pre>
            </div>
          </section>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition"
          >
            Got It, Close Guide
          </button>
        </div>

      </div>
    </div>
  );
};
