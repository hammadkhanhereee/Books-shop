import React from 'react';
import { Book, ShieldCheck, Truck, RotateCcw, ArrowRight, Star } from 'lucide-react';

interface HeroBannerProps {
  onExploreClick: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onExploreClick }) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white rounded-3xl p-6 sm:p-10 mb-10 shadow-2xl border border-indigo-500/20">
      
      {/* Background Subtle Visual Gradients */}
      <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-80 h-80 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none"></div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        
        <div className="lg:col-span-7 space-y-5">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-semibold text-amber-300">
            <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
            <span>Featured Collection & Bestsellers</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-none text-white">
            Feed Your Mind with <br />
            <span className="bg-gradient-to-r from-amber-300 via-amber-200 to-orange-400 bg-clip-text text-transparent">
              Timeless Literature
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
            Welcome to the Simple Book Shop. Browse our curated selection stored in a local Node.js Express backend, search by author or category, and enjoy seamless shopping cart checkout.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              onClick={onExploreClick}
              className="px-6 py-3.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg hover:shadow-amber-400/20 transition-all flex items-center gap-2 group"
            >
              <span>Explore All Books</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <div className="text-xs text-slate-400 font-medium px-3 py-2 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>Express API Endpoint Active</span>
            </div>
          </div>
        </div>

        {/* Featured Book Display Card */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end">
          <div className="relative bg-slate-900/80 backdrop-blur-md p-5 rounded-2xl border border-slate-700/60 shadow-2xl max-w-xs w-full hover:scale-102 transition duration-300">
            <div className="aspect-[3/4] rounded-xl overflow-hidden shadow-inner relative group">
              <img
                src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600"
                alt="The Midnight Library"
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-3 left-3 bg-amber-400 text-slate-950 text-xs font-black px-2.5 py-1 rounded-md shadow">
                #1 Bestseller
              </span>
            </div>

            <div className="mt-4">
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">Fiction</span>
              <h3 className="font-bold text-white text-lg line-clamp-1 mt-0.5">The Midnight Library</h3>
              <p className="text-xs text-slate-400">by Matt Haig</p>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-xl font-extrabold text-amber-300">$16.99</span>
                <span className="text-xs bg-indigo-900 text-indigo-200 px-2.5 py-1 rounded-lg font-semibold">
                  ★ 4.8 / 5
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Feature Pills */}
      <div className="mt-8 pt-6 border-t border-indigo-900/60 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-medium text-slate-300">
        <div className="flex items-center gap-2.5">
          <Truck className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Free Express Delivery over $35</span>
        </div>
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>100% Authentic Publishers</span>
        </div>
        <div className="flex items-center gap-2.5">
          <RotateCcw className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>Easy 30-Day Returns</span>
        </div>
        <div className="flex items-center gap-2.5">
          <Book className="w-4 h-4 text-purple-400 shrink-0" />
          <span>Stored in Local JSON API</span>
        </div>
      </div>

    </div>
  );
};
