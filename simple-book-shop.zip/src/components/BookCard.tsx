import React from 'react';
import { Star, ShoppingBag, Eye, Heart, Check } from 'lucide-react';
import { Book } from '../types/book';

interface BookCardProps {
  book: Book;
  onAddToCart: (book: Book) => void;
  onQuickView: (book: Book) => void;
  isWishlisted: boolean;
  onToggleWishlist: (bookId: string) => void;
  isAdded: boolean;
}

export const BookCard: React.FC<BookCardProps> = ({
  book,
  onAddToCart,
  onQuickView,
  isWishlisted,
  onToggleWishlist,
  isAdded,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden group hover:-translate-y-1">
      
      {/* Cover Image & Badges Container */}
      <div className="relative aspect-[3/4] bg-slate-100 overflow-hidden">
        <img
          src={book.coverImage}
          alt={book.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Overlay Dark Blur on Hover for Quick Actions */}
        <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 p-4">
          <button
            onClick={() => onQuickView(book)}
            className="p-3 bg-white/90 hover:bg-white text-slate-900 rounded-full shadow-lg hover:scale-110 transition-transform font-semibold text-xs flex items-center gap-1.5"
            title="Quick Details"
          >
            <Eye className="w-4 h-4 text-indigo-600" />
            <span>Details</span>
          </button>
        </div>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {book.badge && (
            <span className="bg-indigo-600 text-white text-[10px] font-extrabold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-md">
              {book.badge}
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={() => onToggleWishlist(book.id)}
          className={`absolute top-3 right-3 p-2 rounded-full shadow-md backdrop-blur-md transition ${
            isWishlisted
              ? 'bg-rose-500 text-white'
              : 'bg-slate-900/50 hover:bg-slate-900/80 text-white'
          }`}
          title={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
        >
          <Heart className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-white' : ''}`} />
        </button>
      </div>

      {/* Book Details */}
      <div className="p-4 flex flex-col flex-1">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="font-bold text-indigo-600 uppercase tracking-wider text-[10px]">
            {book.category}
          </span>
          <div className="flex items-center gap-1 text-amber-500 font-bold text-xs">
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span>{book.rating.toFixed(1)}</span>
            <span className="text-slate-400 font-normal">({book.reviewsCount})</span>
          </div>
        </div>

        <h3 className="font-bold text-slate-900 text-base leading-snug line-clamp-1 group-hover:text-indigo-600 transition-colors">
          {book.title}
        </h3>
        <p className="text-xs text-slate-500 mb-2">by {book.author}</p>

        <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed">
          {book.description}
        </p>

        {/* Footer Price & Add Button */}
        <div className="mt-auto pt-3 border-t border-slate-100 flex items-center justify-between">
          <div>
            <span className="text-lg font-black text-slate-900">
              ${book.price.toFixed(2)}
            </span>
            {book.originalPrice && (
              <span className="text-xs text-slate-400 line-through ml-1.5 font-medium">
                ${book.originalPrice.toFixed(2)}
              </span>
            )}
          </div>

          <button
            onClick={() => onAddToCart(book)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-200 flex items-center gap-1.5 shadow-sm ${
              isAdded
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-900 hover:bg-indigo-600 text-white hover:shadow-indigo-500/20'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>

      </div>

    </div>
  );
};
