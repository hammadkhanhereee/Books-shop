import React from 'react';
import { BookOpen, Github, Heart, Mail, Rocket } from 'lucide-react';

interface FooterProps {
  onOpenGuide: () => void;
  categories: string[];
  onSelectCategory: (category: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenGuide,
  categories,
  onSelectCategory,
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 pt-12 pb-8 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="bg-amber-400 p-2 rounded-xl text-slate-900">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="text-lg font-black text-white">Simple Book Shop</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              A beginner-friendly online bookstore built with Node.js, Express, HTML, CSS, JavaScript, and local JSON database storage. Fully optimized for Vercel deployment.
            </p>
          </div>

          {/* Quick Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
              Explore Genres
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => onSelectCategory(cat)}
                    className="hover:text-white transition"
                  >
                    {cat} Books
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Developer Resources */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
              Project & Deploy
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={onOpenGuide} className="hover:text-amber-300 transition flex items-center gap-1.5">
                  <Rocket className="w-3.5 h-3.5 text-amber-400" />
                  <span>Vercel Deployment Guide</span>
                </button>
              </li>
              <li>
                <a href="/vanilla-demo.html" target="_blank" rel="noopener noreferrer" className="hover:text-white transition">
                  ⚡ Vanilla JS Version
                </a>
              </li>
              <li>
                <span className="text-slate-500">API Endpoint: <code>/api/books</code></span>
              </li>
              <li>
                <span className="text-slate-500">Local Data: <code>data/books.json</code></span>
              </li>
            </ul>
          </div>

          {/* Newsletter Box */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-3">
              Newsletter Subscription
            </h4>
            <p className="text-xs text-slate-400 mb-3">
              Subscribe to get weekly updates on new arrivals and special discounts.
            </p>
            <form onSubmit={(e) => { e.preventDefault(); alert('Subscribed to newsletter!'); }} className="flex gap-2">
              <input
                type="email"
                placeholder="Your email address"
                required
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
              <button
                type="submit"
                className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-xl transition"
              >
                Join
              </button>
            </form>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} Simple Book Shop. Express & Node.js Project.</p>
          <div className="flex items-center gap-1">
            <span>Built with clean code & responsive styling</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
