import React from 'react';
import { BookOpen, ShoppingBag, Search, Sparkles, Rocket, X, Heart } from 'lucide-react';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenGuide: () => void;
  wishlistCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  setSearchQuery,
  cartCount,
  onOpenCart,
  onOpenGuide,
  wishlistCount,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-xl backdrop-blur-md bg-opacity-95">
      {/* Top Banner Notice */}
      <div className="bg-indigo-600 text-white text-xs py-1.5 px-4 text-center font-medium flex items-center justify-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
        <span>Free Express Delivery on orders over $35 | Use promo code <strong>BOOKSHOP10</strong> for 10% OFF</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <div className="flex items-center justify-between w-full md:w-auto">
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="bg-gradient-to-tr from-amber-400 to-indigo-500 p-2 rounded-xl text-slate-900 shadow-md group-hover:scale-105 transition-transform duration-200">
              <BookOpen className="w-6 h-6 text-slate-900" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight bg-gradient-to-r from-white via-indigo-200 to-amber-200 bg-clip-text text-transparent">
                Simple Book Shop
              </span>
              <span className="block text-[10px] text-indigo-300 font-semibold tracking-wider uppercase">
                Node.js & Express Powered
              </span>
            </div>
          </a>

          {/* Mobile Right Actions */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={onOpenGuide}
              className="p-2 bg-indigo-950 text-indigo-300 rounded-lg text-xs font-semibold hover:bg-indigo-900 transition flex items-center gap-1"
              title="Vercel Deployment Guide"
            >
              <Rocket className="w-4 h-4 text-amber-400" />
            </button>
            <button
              onClick={onOpenCart}
              className="relative p-2.5 bg-amber-500 text-slate-950 font-bold rounded-xl hover:bg-amber-400 transition"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-indigo-600 text-white text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-slate-900">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="w-full md:max-w-md relative">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search books by title, author, genre..."
              className="w-full pl-10 pr-9 py-2.5 bg-slate-800/90 text-slate-100 placeholder-slate-400 text-sm rounded-xl border border-slate-700/80 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 text-slate-400 hover:text-white p-0.5 rounded-full"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Desktop Header Actions */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="/vanilla-demo.html"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition border border-slate-700/60 flex items-center gap-1.5"
            title="Open Vanilla JS & HTML Demo version"
          >
            <span>⚡ Vanilla Version</span>
          </a>

          <button
            onClick={onOpenGuide}
            className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 text-white text-xs font-bold rounded-xl shadow-md hover:shadow-indigo-500/20 transition flex items-center gap-1.5 border border-indigo-400/30"
          >
            <Rocket className="w-4 h-4 text-amber-300" />
            <span>Deployment Guide</span>
          </button>

          <button
            onClick={onOpenCart}
            className="relative px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition shadow-lg hover:shadow-amber-500/20 flex items-center gap-2 group"
          >
            <ShoppingBag className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span>Shopping Cart</span>
            <span className="bg-slate-950 text-amber-300 px-2 py-0.5 rounded-full text-xs font-extrabold ml-0.5">
              {cartCount}
            </span>
          </button>
        </div>

      </div>
    </header>
  );
};
